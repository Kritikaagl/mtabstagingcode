﻿using JSOTest.wcf.model;
using JSOTest.wcf.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace JSOTest.wcf
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService" in both code and config file together.
    [ServiceContract]
    public interface IService
    {

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETDRIVABLEFAILUREHIST")]
        BaseListReturnType<GET_DRIVABLE_FAILURE_HIST> GETDRIVABLEFAILUREHIST(string P_REG_NUM, string P_VIN);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETDRIVABLEADVICE")]

        BaseListReturnType<GET_DRIVABLE_ADVICE> GETDRIVABLEADVICE(string P_REG_NUM, string P_FAILURE_ID);
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "SUGGESTEDREPAIRPARTS")]

        BaseListReturnType<SUGGESTED_REPAIR_PARTS> SUGGESTEDREPAIRPARTS(string PN_VIN, string PN_CAT_CD, string PN_SUBCAT_CD);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETQAINS")]
        BaseListReturnType<GET_QA_INS> GETQAINS(string PN_REG);

        //RECALL API DETAILS//
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "RecallUserLogin")]
        BaseListReturnType<LoginUserValidate> RecallUserLogin(string PN_USER_ID, string PN_PWD);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "RecallPicDetail")]
        BaseListReturnType<RecallPicDetail> RecallPicDetail(string PN_VIN, string PN_RCAMP_PIC_FLAG);


        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "UpdateRecallStatus")]
        BaseListReturnType<RecallStatus> UpdateRecallStatus(string pn_parent_group, string pn_dealer_map_cd, string pn_loc_Cd, string PN_RO_NUM, string PN_RECALL_STATUS);

        //SCAN APPROVAL SYSTEM//

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "ScanUserLogin")]
        BaseListReturnType<ScanLogin> ScanUserLogin(string PN_USER_ID, string PN_PWD);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "ScanApprovalStatus")]
        BaseListReturnType<ScanApprovalStatus> ScanApprovalStatus(string pn_parent_group, string pn_dealer_map_cd, string pn_loc_Cd, string PN_JOBCARD_NUM, string PN_SCAN_APPR_STATUS, string PN_SCAN_USER_ID);

        //MTAB CCP//

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "Get_CCP_Price")]
        BaseListReturnType<GET_CCP_PRICE> Get_CCP_Price(string pn_pmc, string pn_reg);

        //MTAB INSERT API//

        [OperationContract]
        [WebInvoke(Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "NewInsertAllDetails")]
        BaseListReturnType<NewInsertAllDetailsOutput> NewInsertAllDetails(NewInsertAllDetailsInput mdl);

        //MTAB JC BILLING//

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETJCBILLDTL")]
        BaseListReturnType<GET_JC_BILL_DTL> GETJCBILLDTL(string PN_USER_ID, string PN_JC_NO, string PO_BILL_NUM);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "CALCULATEJCBILL")]
        BaseListReturnType<CALCULATE_JC_BILL> CALCULATEJCBILL(string PN_USER_ID, string PN_JC_NUM);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "CREATEBILLING")]
        BaseListReturnType<JCO_CREATE_BILLING> CREATEBILLING(string PN_USER_ID, string PN_JC_NUM, string PN_DOC_DATE, string PN_PAYMENT_MODE, string PN_INS_NAME, string PN_CUST_CREDIT_CRD_NAME, string PN_CREDIT_CRD_NUM, string PN_VEH_DELIVERED_BY, string PN_INV_PARTY_CD, string PN_INS_COMPANY, string PN_INS_PARTY_CD, string PN_DEDUCTIBLES, string PN_SALVAGE, string PN_REMARKS, string PN_VARIATION_REASON_CD, string PN_DELAY_REASON_CD, string PN_DELAY_REMARKS);


        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETINSURANCECOMPANY")]
        BaseListReturnType<INSURANCE_COMPANY> GETINSURANCECOMPANY();

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETINSURANCEPARTY")]
        BaseListReturnType<INSURANCE_PARTY> GETINSURANCEPARTY(string INS_COMPANY_CD);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETDISCAUTH")]
        BaseListReturnType<GET_DISC_AUTH> GETDISCAUTH(string PN_USER_ID);
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETVEHDELBY")]
        BaseListReturnType<GET_veh_del_by> GETVEHDELBY(string PN_USER_ID);
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETVARIATIONREASON")]
        BaseListReturnType<GET_VARIATION_REASON> GETVARIATIONREASON();
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETBILLDELAYREASON")]
        BaseListReturnType<GET_BILL_DELAY_REASON> GETBILLDELAYREASON();
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GETINVPARTY")]
        BaseListReturnType<GET_INV_PARTY> GETINVPARTY(string INV_PARTY_CD);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GENQRB2C")]
        BaseListReturnType<dynamic> GENQRB2C(string PN_USER_ID, string PN_JC_NUM, string PN_BILL_NUM, string PN_INV_PARTY_CD);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GENQRB2B")]
        BaseListReturnType<dynamic> GENQRB2B(string PN_USER_ID, string PN_JC_NUM, string PN_BILL_NUM, string PN_INV_PARTY_CD);

        //MTAB CONSUMABLE//

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GROUPPARTMCARD")]
        BaseListReturnType<GET_GROUP_PART> GROUPPARTMCARD(string pn_user_id, string PN_PART_NUM, string pn_smodel_cd, string pn_fueltype, string pn_variant_cd, string pn_sub_rcateg_cd, string PN_GROUP_CD, string pn_menu_part_yn, string PN_MTAB_NPAD);


        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "SaveGeoFencingDetails")]
        BaseListReturnType<dynamic> SaveGeoFencingDetails(string PN_RO_NUM, string PN_REG_NUM, string PN_RANGE_CD, string PN_SMART_PICK_FLAG);

        //MTAB LOGIN GET TO POST
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "NewUserAuth")]
        BaseListReturnType<LoginResponse> NewUserAuth(string UserID, string pass, string imei, string version, string vUpdate);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "PullToken")]
        BaseListReturnType<Token> PullToken();
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "UpdateJCDetails")]
        BaseListReturnType<dynamic> UpdateJCDetails(string JC_NUM, string USER_ID, string SRV_CAT_CD, string SUB_SRV_TYPE_CD,
                                       string PROMISED_DATE, string SA_ADV, string TECH_ADV, string BAY_CD, string GROUP_CD, string TECH_CD,
                                       string DEMAND_INS_STR, string PART_INS_STR, string LABOR_INS_STR, string UNAPPRV_FIT_STR,
                                       string PICKUP_TYPE, string PICKUP_DATE, string FREE_PIKCUP_FLAG, string PICKUP_LOC_CD, string PICKUP_DRIVER, string PIKCUP_REMARKS,
                                       string MMS_NUM, string PROB_STR, string CUST_REMARKS, string DLR_REMARKS, string APPRV_STATUS,
                                       double PART_EST_AMT, double OPR_EST_AMT, string REJ_PRT_LAB_INS_STR, string WASH_TYPE, int OCAS_CNT, int SAVE_CNT,
                                       int SENT_CNT, string FINAL_INSPECTION, string ADD_CHK, string ccp_yn, string ccp_num, string holdup_reasn_cd,string pn_quote_id, int pn_se_part_amt, int pn_se_labour_amt, int pn_se_total_amt, int pn_se_images_cap, int pn_se_damage_cap);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetGroupDetails")]
        BaseListReturnType<GroupDetails> GetGroupDetails(string userID);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetTechAdv")]
        BaseListReturnType<GetTechAdv> GetTechAdv(string userID);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetSaAdv")]
        BaseListReturnType<GetSaAdv> GetSaAdv(string userID);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetServiceCategory")]
        BaseListReturnType<GetServiceCategory> GetServiceCategory(string userID);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetCityDetails")]
        BaseListReturnType<GetCityDetails> GetCityDetails(string userID);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetRFTagDetails")]
        BaseListReturnType<RfTagDetails> GetRFTagDetails(string parentGroup, string dealerCode, string locationCode, string userId, string vin, string srvCategory);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "HistoryMaster")]
        BaseListReturnType<HistoryMaster> HistoryMaster(string RegNum);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetRFTagScanTime")]
        BaseListReturnType<GetRFTagScanTime> GetRFTagScanTime(Int32 dealerCode, string locationCode, string userId, string rftagNo, string srvCategory);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "NewBillPrint")]
        BaseListReturnType<NewBillPrint> NewBillPrint(string userID, string JobCardnum);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetAppointmentDetails")]
        BaseListReturnType<AppointmentDetails> GetAppointmentDetails(string userID, int dealer_cd, string loc_cd, string isTesting = "1");

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetJCOpenDetails")]
        BaseListReturnType<JCOpenDetails> GetJCOpenDetails(string Jcmodule, string UserID, string Parent_group, string Dealer_map_cd, string Loc_Cd, string Comp_fa, string Jcno);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetSrvDemandLabourDetails")]
        BaseListReturnType<GET_SRV_DEMAND_LABOUR> GetSrvDemandLabourDetails(string PN_SRV_TYPE);

        //JWT Token 

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GenerateToken")]
        Tokens GenerateToken(string UserId, string Password);
        
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GenerateRefreshToken")]
        Tokens GenerateRefreshToken(string UserId, string Password);

        //[OperationContract]
        //[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "AuthenticateJWTToken")]
        //ServiceHeaderInfos1 AuthenticateJWTToken();

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "RefreshToken")]
        BaseListReturnType<Tokens> RefreshToken(string UserName, string Password);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "logout")]
        BaseListReturnType<dynamic> logout(string token);

        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "OCASLoginValidate")]
        BaseListReturnType<OCASLogin> OCASLoginValidate(string pn_userid, string pn_pwd, string pn_user_type);

    }

}
